from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB"""

    def __init__(self, username, password):
        """
        Initializes the MongoDB connection and sets up the database and collection.
        """
        # MongoDB Connection Variables
        #USER = "aacuser"  # MongoDB username
        #PASS = "aacuser"  # MongoDB password
        HOST = "nv-desktop-services.apporto.com"  # MongoDB server hostname
        PORT = 34115  # MongoDB port number
        DB = "AAC"  # Database name
        COL = "animals"  # Collection name

        # Establishing a connection to MongoDB using the provided credentials
        #self.client = MongoClient(f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource=admin")
        self.client = MongoClient(f"mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin")

        # Accessing the specified database
        self.database = self.client[DB]

        # Accessing the specified collection within the database
        self.collection = self.database[COL]

    def create(self, data):
        """
        Inserts a new document into the MongoDB collection.
        
        Parameters:
        - data (dict): A dictionary containing key-value pairs representing the document to insert.

        Returns:
        - bool: True if insertion is successful, False otherwise.
        """
        if data and isinstance(data, dict):  # Ensure the input is a dictionary and not empty
            try:
                # Insert the document into the collection
                result = self.collection.insert_one(data)

                # Check if the insertion was acknowledged by MongoDB
                return True if result.acknowledged else False
            except Exception as e:
                print(f"Error inserting document: {e}")  # Print error message if insertion fails
                return False
        else:
            raise ValueError("Data must be a non-empty dictionary")  # Raise an error if input is invalid

    def read(self, query):
        """
        Retrieves documents matching a given query from the MongoDB collection.
        
        Parameters:
        - query (dict): A dictionary containing key-value pairs representing the search criteria.

        Returns:
        - list: A list of matching documents, or an empty list if no matches are found.
        """
        if query and isinstance(query, dict):  # Ensure input is a dictionary
            try:
                # Execute the query using the find() method
                results = list(self.collection.find(query))

                # Return the list of matching documents
                return results if results else []
            except Exception as e:
                print(f"Error retrieving documents: {e}")  # Print error message if query fails
                return []
        else:
            raise ValueError("Query must be a non-empty dictionary")  # Raise an error if input is invalid

    def update(self, query, new_values):
        """
        Updates documents in the MongoDB collection.

        Parameters:
        - query (dict): A dictionary specifying the query to find the document(s).
        - new_values (dict): A dictionary specifying the new values to update.

        Returns:
        - int: The number of documents updated.
        """
        if query and isinstance(query, dict) and new_values and isinstance(new_values, dict):
            try:
                update_result = self.collection.update_many(query, {"$set": new_values})
                return update_result.modified_count  # Return the number of modified documents
            except Exception as e:
                print(f"Error updating document: {e}")
                return 0  # Return 0 if update fails
        else:
            raise ValueError("Query and new values must be non-empty dictionaries")

    def delete(self, query):
        """
        Deletes documents from the MongoDB collection.

        Parameters:
        - query (dict): A dictionary specifying the query to find the document(s) to delete.

        Returns:
        - int: The number of documents deleted.
        """
        if query and isinstance(query, dict):
            try:
                delete_result = self.collection.delete_many(query)
                return delete_result.deleted_count  # Return the number of deleted documents
            except Exception as e:
                print(f"Error deleting document: {e}")
                return 0  # Return 0 if deletion fails
        else:
            raise ValueError("Query must be a non-empty dictionary")
